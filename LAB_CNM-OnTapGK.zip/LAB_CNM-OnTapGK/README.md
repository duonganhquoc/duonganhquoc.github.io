
# Bài Tập Công Nghệ Mới
## Ôn Tập giữa kỳ
 [install nodeJs](https://nodejs.org/en)
 , use expresJs 
code : `npm start` go to "http://localhost:3001/"
### Demo App
![Alt text](https://i.imgur.com/LFAYNjA.png)
 



