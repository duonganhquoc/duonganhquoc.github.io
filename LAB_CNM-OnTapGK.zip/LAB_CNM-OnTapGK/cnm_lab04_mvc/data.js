// tạo 1 data
const data = [
  {
    id: 1,
    name: 'Toán rời rạc',
    course_type: 'Toán',
    semester: 'HK1-2024-2025',
    department: 'Khoa Toán',
    image: {
      path: 'image/pic1.jpg',
    },
  },
  {
    id: 2,
    name: 'Cơ sở dữ liệu',
    course_type: 'Cơ sở',
    semester: 'HK1-2024-2025',
    department: 'Khoa CNTT',
    image: {
      path: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEBqYEUHs9SPync2bo8AmdYjzW5WYicOWF8lreCXnMcQ&s',
    },
  },
]
export default data
